#include <stdio.h>
#include "magicSquare.h"

int cuadradoMagico(int filas, int columnas, int cuadrado[filas][columnas]) {
    int sumas[filas + columnas + 2];
    int diagonalPrincipal = 0;
    int diagonalSecundaria = 0;

    // Inicializar sumas en 0
    for (int i = 0; i < filas + columnas + 2; i++) {
        sumas[i] = 0;
    }

    // Calcular la suma de cada fila, columna y diagonal
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            sumas[i] += cuadrado[i][j];
            sumas[j + filas] += cuadrado[i][j];

            if (i == j) {
                diagonalPrincipal += cuadrado[i][j];
            }

            if (i + j == filas - 1) {
                diagonalSecundaria += cuadrado[i][j];
            }
        }
    }

    // Comprobar si todas las sumas son iguales
    int sumaBase = sumas[0];
    for (int i = 1; i < filas + columnas + 2; i++) {
        if (sumas[i] != sumaBase) {
            return 0; // No es un cuadrado mágico
        }
    }

    // Comprobar si las diagonales tienen la misma suma
    if (diagonalPrincipal != sumaBase || diagonalSecundaria != sumaBase) {
        return 0; // No es un cuadrado mágico
    }

    return 1; // Es un cuadrado mágico
}

int calcularConstanteMagica(int filas, int columnas, int cuadrado[filas][columnas]) {
    int sumas[filas + columnas + 2];
    int constanteMagica;

    // Inicializar sumas en 0
    for (int i = 0; i < filas + columnas + 2; i++) {
        sumas[i] = 0;
    }

    // Calcular la suma de cada fila, columna y diagonal
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            sumas[i] += cuadrado[i][j];
            sumas[j + filas] += cuadrado[i][j];
        }
    }

    // Calcular la constante mágica
    constanteMagica = sumas[0];

    return constanteMagica;
}

void imprimirCuadrado(int filas, int columnas, int cuadrado[filas][columnas]) {
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            printf("%2d ", cuadrado[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}